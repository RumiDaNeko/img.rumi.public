import en from "./en.json" with { type: "json" };
import vi from "./vi.json" with { type: "json" };
import tr from "./tr.json" with { type: "json" };

export default {
    en,
    vi,
    tr,
}